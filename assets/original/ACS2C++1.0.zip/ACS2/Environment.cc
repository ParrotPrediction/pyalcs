/*
/       ACS2 in C++
/	------------------------------------
/       choice of without/with GA, subsumption, PEEs
/
/     (c) by Martin V. Butz
/     University of Wuerzburg / University of Illinois at Urbana/Champaign
/     butz@illigal.ge.uiuc.edu
/     Last modified: 02-23-2001
/
/     base class of all environment classes.
*/

#include"Action.h"
#include"Perception.h"
#include"Environment.h"

/**
 * Default constructor.
 */
Environment::Environment()
{;
}

